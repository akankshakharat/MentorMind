package com.example.crm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRelationshiopManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
