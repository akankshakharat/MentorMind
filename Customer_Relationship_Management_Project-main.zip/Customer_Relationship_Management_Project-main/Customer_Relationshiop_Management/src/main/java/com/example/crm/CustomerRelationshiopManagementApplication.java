package com.example.crm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerRelationshiopManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRelationshiopManagementApplication.class, args);
		System.out.println("Successfully run");
	}

}
